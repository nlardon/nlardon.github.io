Le code pour la quatrieme enigme est contenu dans le fichier style.txt qui se 
trouve dans le repertoire Langages/Web/CSS.
