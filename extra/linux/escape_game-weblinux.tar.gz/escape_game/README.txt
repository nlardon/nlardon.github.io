Vous devez repondre a 6 enigmes pour reconstituer le mot de passe et sortir du jeu.

La reponse a la premiere enigme est donnee par l'execution du programme enigme1 dans le repertoire Langages/Python
