Aller dans le repertoire Personnes pour la troisieme enigme:
- le 1er chiffre du code correspond au nombre de fichiers dans ce repertoire
- le 2eme chiffre code correspond au nombre de sous-repertoires
